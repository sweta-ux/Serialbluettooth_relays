#include <WiFiClientSecure.h>
#include <Client.h>
#include <MQTT.h>
#include <iotmqtt.h>
#include <CloudCore.h>
#include "cloud.h"
#include "ble.h"
#include "definitions.h"

/* declaring object of the class */
Client *netClient;
iotdevice *device;
iotmqtt *mqtt;
MQTTClient *mqttClient;

boolean skip;
const char *cloud_device_id;

/* extern structure */
extern struct cloud_def _config;

/**
 * start_wifi-> initialising wifi
 * args: void
 * returns: int
 */
void wifi_start(struct cloud_def *_config) {
  if (WiFi.status() != WL_CONNECTED) {
    WiFi.begin( _config->wifi_ssid, _config->wifi_pass );
    show_notification(wifi_connecting, 4);
    DELAY_1000;
    display_wifi_name("SSID: ", 5, 20, _config->wifi_ssid, 5, 40);
    PRINTS("IP Address: ");
    Serial.println(WiFi.localIP());
    #ifdef WIFIMINI
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    #endif
    DELAY_100;
  }  
}

/**
 * start_wifi - enable wifi when SSID/Pass is available
 * args: void
 * return: int
 */
int check_wifi(void) {
  WiFi.mode(WIFI_STA);
  DELAY_100;
  uint8_t i = 0;
  while ((WiFi.status() != WL_CONNECTED) && (i <= 20)) {
    PRINTS(".");
    show_notification("", 5);
    if ((++i % 20) == 0) {
      return FAILURE;     
    }
  }
  show_notification("", 6); /* green color led will blink */
  return SUCCESS;
}

/**
 * getjwt-> getting jwt as in string 
 * args: null
 * returns: string
 */
String getJwt() {    
/* Time (seconds) to expire token += 20 minutes for drift*/
/* Maximum 24H (3600*24) */
  const int jwt_exp_secs = 3600*24;
  unsigned long iat = time(nullptr);
  PRINTR("Refreshing JWT");
  String jwt = device->createJWT(iat, jwt_exp_secs);
  return jwt;
}

/*/**
 *publish_state-> method for sending data on state topic
 * args: String data
 * returns: bool
 */
bool publish_state(String data) {
  return mqtt->publishState(data);
}

/** 
 * mqtt_connect-> connect with mqtt 
 * args: bool skip
 * returns: int
 */
void mqtt_connect(bool skip) {
  int __backoff__ = 1000; // current backoff, milliseconds
  static const int __factor__ = 2.5f;
  static const int __minbackoff__ = 1000; // minimum backoff, ms
  static const int __max_backoff__ = 60000; // maximum backoff, ms
  static const int __jitter__ = 500; // max random jitter, ms
  PRINTR("Connecting...");
  bool keepgoing = true;
  if (keepgoing) {
    bool result =mqttClient->connect( device->getClientId().c_str(), "unused", getJwt().c_str(), skip);
    if (mqttClient->lastError() != LWMQTT_SUCCESS && result) {
      log_error();
      log_return_code();
      if (__backoff__ < __minbackoff__) {
        __backoff__ = __minbackoff__;
      }
      __backoff__ = (__backoff__ * __factor__) + random(__jitter__);
      if (__backoff__ > __max_backoff__) {
        __backoff__ = __max_backoff__;
      }
      // Clean up the client
      mqttClient->disconnect();
      skip = false;
      PRINTR("Delaying " + String(__backoff__) + "ms");
      delay(__backoff__);
      keepgoing = true;
    } else {
      PRINTR(mqttClient->connected() ? "connected" : "not connected");
      if (!mqttClient->connected()) {
        notify_msg(mqtt_disconnect);
        PRINTR("Retrying to connect");
        show_error(); /* red led blink */
        mqttClient->disconnect();
        skip = false;
        keepgoing = true;
        PRINTR("Waiting 60 seconds");
        delay(__max_backoff__);
      } else {
        // We're now connected
        PRINTR("\nLibrary connected!");
        keepgoing = false;
        __backoff__ = __minbackoff__;
      }
    }
  }
  mqttClient->subscribe(device->getCommandsTopic(), 1);

  /* sending device_config on state topic */
  String on_connect = device_info();
  publish_state(on_connect);
}

/**
 * device_info:- information of device with mac-add
 * args:- void
 * ret:- void
 */
String device_info() {
  String device_config = String("{\"device_id\":\"") + cloud_device_id + \
                        String("\",\"mac_address\":\"") + mac_address() + \
                        String("\",\"version\":\"") + CODE_VERSION + \
                        String("\",\"ap_mode_id\":\"") + device_name() + \
                        String("\",\"status\":\"") + "5" + \
                        String("\"}");
  PRINTR(device_config);
  return device_config;
}

/**
 * connect-> connect with wifi and mqtt
 * args: void
 * ret: int
 */
void connect() {
  int ret = check_wifi();
  int counter = 0;
  if (ret != SUCCESS) {
    while (counter < 3) {
      wifi_start(&_config);
      counter ++;
      
      ret = check_wifi();
      if (ret != FAILURE)
      break;
    }

    while (counter >= 3) {
      show_notification(reset_device, 1);
      // bluetooth initialize
      init_ble();
      
    }
  }
  DELAY_100;
  mqtt_connect(skip);
}

/**
 * start_mqtt-> initialized mqtt 
 * args: void
 * ret: int
 */
void start_mqtt() {
  //boolean enabled;
  boolean useLts = true;
  boolean enabled = useLts;
  mqttClient->begin(enabled ? MQTT_HOST_LTS : MQTT_HOST,MQTT_PORT, *netClient);
}

/**
 * setup_iot_cloud-> initalized cloud
 * args: void
 * ret: void
 */
int setup_iot_cloud(struct cloud_def *_config) {
  device = new iotdevice(_config->cloud_project_id, _config->cloud_location, _config->cloud_registry_id, _config->cloud_device_id, _config->cloud_private_key);
  cloud_device_id = _config->cloud_device_id; 
  netClient = new WiFiClientSecure();
  if (!netClient)
    return FAILURE;

  mqttClient = new MQTTClient(512);
  if (!mqttClient) {
    /* Release netClient */
    mqttClient = NULL;
    return FAILURE;
  }
  mqttClient->setOptions(180, true, 1000); // keepAlive, cleanSession, timeout
  mqtt = new iotmqtt(mqttClient, netClient, device);
  if (!mqtt) {
    /* Release mqttClient, netClient */
    mqttClient = NULL;
    netClient = NULL;
    return FAILURE;
  }
  mqtt->setUseLts(true);
  start_mqtt();
  return SUCCESS;
}

/**
 * reconnect-> reconnect with wifi and mqtt
 * args: void
 * ret: void
 */
void check_mqtt_reconnect() {
  mqtt->loop();
  DELAY_100;  
  if (!mqttClient->connected()) {
    connect();
  }
}

/**
 * log_error-> returning mqtt error while connecting with mqtt
 * args: void
 * ret: int
 */
int log_error(void) {
  int error2 = mqttClient->lastError();
  if (error2 == 0) {
    PRINTS("LWMQTT_SUCCESS");
  } else if (error2 == -1) {
    PRINTS("LWMQTT_BUFFER_TOO_SHORT");
  }else if (error2 == -2) {
    PRINTS("LWMQTT_VARNUM_OVERFLOW"); 
  } else if (error2 == -3) {
    PRINTS("LWMQTT_NETWORK_FAILED_CONNECT");
  }
  return error2;
}

/**
 * log_return_code-> returning mqtt error while connecting with mqtt
 * args: void
 * ret: int
 */
int log_return_code(void) {
  int error1 = mqttClient->returnCode();
  if (error1 == 0) {
    PRINTS("LWMQTT_CONNECTION_ACCEPTED");
  } else if (error1 == -1) {
    PRINTS("LWMQTT_UNACCEPTABLE_PROTOCOL");
  } else if (error1 == -2) {
    PRINTS("LWMQTT_IDENTIFIER_REJECTED");
  } else if (error1 == -3) {
    PRINTS("LWMQTT_SERVER_UNAVAILABLE");
  }
  return error1;
}