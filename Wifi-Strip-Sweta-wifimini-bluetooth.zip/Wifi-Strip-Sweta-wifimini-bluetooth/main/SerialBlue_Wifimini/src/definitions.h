/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef DEFINITION_H
#define DEFINITION_H

#define WIFIMINI
//#define WIFISTRIP

/* Debugging switches and macros
 Switch debug output on and off by 1 or 0*/
#define DEBUG 1

#if DEBUG
#define PRINTS(...) Serial.print(__VA_ARGS__)
#define PRINTR(...) Serial.println(__VA_ARGS__)
#else
#define PRINTS(s)
#define PRINTR(s)
#endif

#define DELAY_100 delay(100);
#define DELAY_5000 delay(50)
#define DELAY_200 delay(200)
#define DELAY_1000 delay(1000)
#define DELAY_2000 delay(2000)

#define SUCCESS 0
#define FAILURE 1

/* define num of relays */
#ifdef WIFISTRIP
#define NUM_RELAYS 4
#endif

#ifdef WIFIMINI
#define NUM_RELAYS 3
#endif

/* ERROR CODES */
#define hardware_error "ERHW" /* HARDWRAE ERROR */
#define memory_error "ERMM" /* MEMORY ERROR */
#define no_data_in_nv "ERNV" /* NO DATA */
#define reset_device    "RST" /* RESET DEVICE */
#define invalid_json "ERIJ" /* INVALID JSON */
#define please_wait "WAIT" /* CLEAR NV */

/* OLED NOTIFICATION FOR USER */
#define start_msg "HELLO"
#define server_mode "CONFIG..."
#define wifi_connect "WAITING..."
#define wifi_connecting "CONNECTING..."
#define mqtt_disconnect "ERR01" /* Mqtt Not connect */

#define wifistrip_name "VCAUTO_001_"
#define wifimini_name "VCAUTO_003_"

/* MAX TIME FOR SENDING PERIODIC DATA */
//#define max_sending_time 10000   /* SEDNING JSON TIME */
//#define max_sending_time 360000  /* SEDNING JSON TIME FOR TESTING */
#define max_sending_time 600000 /* SEDNING JSON TIME FOR TESTING */

#define data_file "/data.txt"

#define CODE_VERSION 100
/**
 * cloud - define the structure for cloud configuration
 */
struct cloud_def {
  const char *wifi_ssid;
  const char *wifi_pass;
  const char *cloud_project_id;
  const char *cloud_location;
  const char *cloud_device_id;
  const char *cloud_private_key;
  const char *cloud_registry_id;
};

#endif