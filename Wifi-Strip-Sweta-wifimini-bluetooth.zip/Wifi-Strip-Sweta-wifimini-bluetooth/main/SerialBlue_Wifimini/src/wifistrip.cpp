/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
/* Defining The Libraries */
#include "cloud.h"
//#include "apmode.h"
#include "nv.h"
#include "ntp.h"
#include "server_response.h"
#include "ble.h"

struct cloud_def _config = {0}; /* make it heap memory */
struct relay_def *relay;

/**
 * setup - 
 */
void setup()
{
  Serial.begin(115200);
  PRINTR("Bluetooth Device is Ready to Pair");
  int counter = 0;
  int ret;
  ret = init_hardware();
  if (ret != SUCCESS) {
    while(1) {
      /* stuck in while, if getting error in hardware */
      show_notification(memory_error, 8);
    }
  }

  /* ToDo : define function*/
  relay = (struct relay_def *)malloc(sizeof(struct relay_def) * 4);
  if (!relay) {
    PRINTR(hardware_error);
    /* ToDo
      error handling with oled */
  } else {
    memset(relay, 0, sizeof(struct relay_def) * 4);
  }
  
  xTaskCreatePinnedToCore(reset_and_toggle_relays, "RESET_AND_TOGGLE_RELAYS", 10000, NULL, 0, NULL, 0);
  //xTaskCreatePinnedToCore(receive_message_from_ble, "RECEIVING_MESSAGE FROM", 10000, NULL, 0, NULL, 1); 
  #ifdef WIFISTRIP
  xTaskCreatePinnedToCore(oled_led_on_off, "OLED_LED_ON_OFF", 10000, NULL, 0, NULL, 0); //TODO:Change name
  #endif
  attachInterrupt(digitalPinToInterrupt(JSON_INTERRUPT), send_json, FALLING);

restart_ap_mode:
  do {
    ret = validate_nv(&_config);
    if (ret != SUCCESS) {
      show_notification(no_data_in_nv, 2);
      init_ble();
      continue;
    }
    
    // wifi Initialization
    // Not checked for error as global variable would
    // set against this.
    while (counter < 10) {
      wifi_start(&_config);
      counter ++;
      
      ret = check_wifi();
      if (ret != FAILURE)
      break;
    }

    while (counter >= 10) {
      show_notification(reset_device, 1);
      // bluetooth initialize
      init_ble();
    }

    // Assuming check_wifi has updated its return into 'ret'
    if (ret != FAILURE)
      break;
      
    ret = validate_nv(&_config);
  } while(1);

  ret = init_ntp();
  if (ret != SUCCESS) {
    PRINTR("TIME NOT SET");
  }

  //setup_iot_cloud(&_config); 
  ret = setup_iot_cloud(&_config);
  if (ret != SUCCESS) {
    goto restart_ap_mode;
  }

  xTaskCreatePinnedToCore(receive_from_server, "RECEIVE_FROM_SERVER", 10000, NULL, 0, NULL, 0); 
  xTaskCreatePinnedToCore(send_to_server_periodically, "SEND_TO_SERVER", 10000, NULL, 0, NULL, 1);
}

/**
 * 
 */
void loop() {
  oled_frame();
  DELAY_1000;
  check_mqtt_reconnect();
  DELAY_1000;
}