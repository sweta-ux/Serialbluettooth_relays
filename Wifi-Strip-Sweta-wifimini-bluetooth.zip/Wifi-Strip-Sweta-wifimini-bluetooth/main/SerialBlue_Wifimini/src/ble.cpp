#include "WiFi.h"
#include "ble.h"
#include <ArduinoJson.h>
#include "definitions.h"
#include "hardware.h"
#include "nv.h"
#include "server_response.h"
#include "BluetoothSerial.h" //Header File for Serial Bluetooth, will be added by default into Arduino
BluetoothSerial ESP_BT; //Object for Bluetooth

char device_ssid[30];
bool connected;

/**
 * mac_aadress:- fetching mac address of esp32
 * args: void
 * ret: String
*/
void init_ble(void) {
  WiFi.mode(WIFI_OFF);
  char *ble_id = device_name();
  ESP_BT.begin(ble_id);
  PRINTR("in ble");
  receive_message_from_ble();
}

/**
 * device_name:- fetching mac address of from an array
 * args: void
 * ret: char *
 */
char *device_name(void) {
  String mac = mac_address();
  int str_len = mac.length() + 1;
  char mac_add[str_len];
  mac.toCharArray(mac_add, str_len);
  char mac1 = mac_add[9];
  char mac2 = mac_add[10];
  char mac4 = mac_add[12];
  char mac5 = mac_add[13];
  char mac7 = mac_add[15];
  char mac8 = mac_add[16];
  String add = String(mac1)+String(mac2)+String(mac4)+String(mac5)+String(mac7)+String(mac8);
  #ifdef WIFIMINI
    String ap_mode_name = wifimini_name + add;
  #else
    String ap_mode_name = wifistrip_name + add;
  #endif
  ap_mode_name.toCharArray(device_ssid, str_len);
  return device_ssid;
}

/**
 * mac_aadress:- fetching mac address of esp32
 * args: void
 * ret: String
*/
String mac_address(void) {
  String newmac = WiFi.macAddress();
  return newmac;
}

void receive_message_from_ble() {
  while (WiFi.status() != WL_CONNECTED) {
    if (ESP_BT.available()) {//Check if we receive anything from Bluetooth
      String ble_json = ESP_BT.readString(); //Read what we recevive
      if (ble_json != "NULL") {
      //message += String(ble_json);
      PRINTR("Received:");
      PRINTR(ble_json);
     }  else {
      ble_json = "";
     }
      DynamicJsonBuffer jsonBuffer(800);
      JsonObject& root = jsonBuffer.parseObject(ble_json);
      if (!root.success()) {
        PRINTR("invalid json");
        show_notification(invalid_json, 1);
        ble_json = " ";
      }
      int cloud_ver  = root["version"];  
      if (cloud_ver == CODE_VERSION) {
        String aim = root["aim"];
        String src = root["src"];
        PRINTR(aim);
        if (aim == "onboarding") {
          PRINTR("writing in nv");
          //fed_values_in_struct ();
          int ret = nv_write(SPIFFS, data_file, ble_json.c_str());
          DELAY_1000;
          if (ret != SUCCESS) {
            //continue;
            PRINTR("not written in nv");
          } else {
            ESP_BT.disconnect();
            ESP_BT.end();
            DELAY_1000;
            WiFi.mode(WIFI_STA);
            break;
          }
        }
        if (aim == "toggling") {
          int cmd = root["cmd"];
          String url = root["url"];
          String random_string = (const char*)root["commandId"];
          String peripherals = root["peripheral"];
          String weather = root["weather"];
          
          /* checking cmd */
          check_cmd(cmd, peripherals, url, src, weather);
          ble_json = " ";
        }   
      } else {
        /* Drop the packet if version not valid*/
        ble_json = " ";
      }
    }
  }
  DELAY_200;
 }
