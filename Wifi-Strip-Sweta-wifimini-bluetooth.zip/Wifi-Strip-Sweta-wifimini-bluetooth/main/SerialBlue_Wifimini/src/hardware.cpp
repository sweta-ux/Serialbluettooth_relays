#include "hardware.h"
#include "nv.h"
#include "cloud.h"
#include "server_response.h"
#include "oled.h"

extern struct relay_def *relay;

/**
 * set RGB color
 * args: void
 * return: void
 */
void RGB_color(int red_light_value, int green_light_value, int blue_light_value) {
  analogWrite(Red, red_light_value);
  analogWrite(Green, green_light_value);
  analogWrite(Blue, blue_light_value);
}

/**
 * show_error - red led blink
 * args: void
 * return: void
 */
void show_error() {
  RGB_color(255, 0, 0); // Red
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}

/**
 * show_hadware_error - Blink Red Led with 5sec delay
 * args: String, int
 * ret: void
 */
void show_hardware_error() {
  RGB_color(255, 0, 0); // Red
  DELAY_5000;
  RGB_color(0, 0, 0); 
  DELAY_5000;
}

/**
 * connecting_wifi - Blink Green Led with 5sec delay
 * args: String, int
 * ret: void
 */
void connecting_wifi() {
  RGB_color(0, 255, 0); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}
/**
 * show_error - show error based on led
 * args: void
 * return: void
 */
void show_clear_nv() {
  /* orange led blink */
  RGB_color(255, 165, 0);
  DELAY_1000;
}

/**
 * show_error -  yellow led blink 
 * args: void
 * return: void
 */
void show_nv_error() {
  RGB_color(255, 204, 0);
  DELAY_100;
  RGB_color(255, 204, 0);
  DELAY_100;
}

/**
 * show success - green led blink
 * args: void
 * return: void
 */
void show_success() {
  RGB_color(0, 255, 0); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}

/**
 * show success - blue led blink
 * args: void
 * return: void
 */
void show_web_server() {
  RGB_color(0, 0, 255); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}
/**
 * show success - tri color led blink
 * args: void
 * return: void
 */
void wifi_connecting_error() {
  RGB_color(0, 0, 255); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100; /* BLUE */
  RGB_color(0, 255, 0); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100; /* GREEN */
  RGB_color(255, 0, 0);
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100; /* Red */
}

/**
 * init_gpio_pins: initialize GPIO pins
 * args: void
 * return: void
 */
void init_gpio_pins() {
  pinMode(Red, OUTPUT);
  pinMode(Green, OUTPUT);
  pinMode(Blue, OUTPUT);
  pinMode(R1, OUTPUT);
  pinMode(R2, OUTPUT);
  pinMode(R3, OUTPUT);
  pinMode(USB, OUTPUT);
  pinMode(OLED_RESET, INPUT);
  pinMode(NIGHT_LAMP, OUTPUT);
  pinMode(ALL_ON_OFF_RESET_NV, INPUT_PULLUP);
  pinMode(JSON_INTERRUPT, OUTPUT);
  digitalWrite(ALL_ON_OFF_RESET_NV, HIGH);
  digitalWrite(JSON_INTERRUPT, HIGH);
}

/**
 * args: void
 * returns:
 *  !0 for error
 *  0 for success
 */
int init_hardware() {
  // Initialize GPIO Pins
  /* ToDo :- fiexed error handling for oled and pins*/
  init_gpio_pins();

  // Oled Initialization
  // Not checked for error as global variable would
  // set against this.
  oled_init();
  int ret = nv_mount();
  if (ret != SUCCESS) {
    PRINTR("NV NOT MOUNT");
  }
  return ret;
}

/**
 * reset_and_toggle_relays - using single switch for clear nv and restart esp again and operating relays maually
 * args: void
 * return: void
 * to-do: need to decide on which core reset_nv has to run beacuse
 *    it might be possibilities of error like - ap_mode running on core_1 and interrupt
 *    running on core_0 then, due to delay in code possibilities of error will occur
 */
void reset_and_toggle_relays(void *pv) {
  PRINTS("reset_and_toggle_relays running on core ");
  PRINTR(xPortGetCoreID());
  int switch_count = 0;
  for(;;) {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    int read_switch = digitalRead(ALL_ON_OFF_RESET_NV);
    int a = 0;
    if ((read_switch == 0) && (a == 0)) {
      switch_count++;
      a = 1;
      PRINTS("switch count = ");
      PRINTR(switch_count);
    }
    /* For toggle relays */
    if ((switch_count == 1) && (read_switch == 0)) {
    #ifdef WIFISTRIP 
      for (int i = 1; i <= NUM_RELAYS; i++) {
        relay[i].state = 1;
        toggle_relay(i);
      }
      if ((WiFi.status() == WL_CONNECTED)) {
        /* Checking Wifi Status */
        publish_on_telemetry();
      }
      //apply delay for avoiding reading
      DELAY_100;
    } else if ((switch_count == 2) && (read_switch == 1)) {
      switch_count = 0;
      for (int i = 1; i <= NUM_RELAYS; i++) {
        relay[i].state = 0;
        toggle_relay(i);
      }
      if ((WiFi.status() == WL_CONNECTED)) { 
        /* Checking Wifi Status */
        publish_on_telemetry();
      }
      //apply delay for avoiding reading
      DELAY_100;
      #endif
    } else if ((switch_count >= 3) && (read_switch == 1)) {
      switch_count = 0;
    } else if ((switch_count >= 10) && (read_switch == 0)) {   /* For Reset NV */
      switch_count = 0;
      show_notification(please_wait, 7);
      clear_nv();
      ESP.restart();
    }
    DELAY_100;
  }
}