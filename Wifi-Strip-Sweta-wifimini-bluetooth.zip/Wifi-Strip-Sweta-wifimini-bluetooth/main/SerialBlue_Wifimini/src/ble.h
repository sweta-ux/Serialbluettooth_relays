#ifndef BLE_H
#define BLE_H


void init_ble(void);
char *device_name(void);
String mac_address(void);
void receive_message_from_ble (); 

#endif
