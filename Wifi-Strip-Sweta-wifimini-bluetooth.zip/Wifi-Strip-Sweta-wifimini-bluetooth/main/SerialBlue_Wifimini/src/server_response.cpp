#include "hardware.h"
#include "cloud.h"
#include "nv.h"
#include "server_response.h"
#include <MQTT.h>
#include <ArduinoJson.h>
#include <iotmqtt.h>
#include <Arduino.h>

extern MQTTClient *mqttClient;
extern iotmqtt *mqtt;

#ifdef WIFISTRIP
int relaygpios[NUM_RELAYS] = {R1, R2, R3, USB};
#endif

#ifdef WIFIMINI
int relaygpios[NUM_RELAYS] = {R1, R2, R3};
#endif

bool interrupt_flag = false;

/* defining string for response */
String random_string;
int cmd;

/* extern structures */
extern struct relay_def *relay;
extern struct cloud_def _config;
struct temp_weather_def _weather;

/**
 * received_message-> creating a task for receving msg from the cloud 
 * args: void *pvParameters
 * returns: void
 */
void receive_from_server(void *pvParameters) {
  PRINTS("RECEIVE_FROM_SERVER running on core ");
  PRINTR(xPortGetCoreID());
  for(;;) {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    mqttClient->onMessage(message_received);
  }
  DELAY_200;
}

/**
 * message_received - function fore receing the message from the mqtt
 * args: string topic, string payload
 * return: void
 */
void message_received(String &topic, String &payload) {
  PRINTR("incoming: " + topic + " - " + payload);
  //const size_t bufferSize = JSON_ARRAY_SIZE(1) + JSON_OBJECT_SIZE(1) + 2*JSON_OBJECT_SIZE(2) + JSON_OBJECT_SIZE(4) + JSON_OBJECT_SIZE(5) + JSON_OBJECT_SIZE(6) + JSON_OBJECT_SIZE(12) + 976;
  DynamicJsonBuffer jsonBuffer(300);
  JsonObject& root = jsonBuffer.parseObject(payload);
  if (!root.success()) {
    PRINTR("invalid json");
    show_notification(invalid_json, 1);
  }

  /* version getting from cloud */
  int cloud_ver  = root["version"];
  
  if (cloud_ver == CODE_VERSION) {
    cmd = root["cmd"];
    PRINTR(cmd);
    String url = root["url"];
    random_string = (const char*)root["commandId"];
    String peripherals = root["peripheral"];
    String weather = root["weather"];
    String src = root["src"];

    /* checking cmd */
    check_cmd(cmd, peripherals, url, weather, src);
  } else {
    /* Drop the packet if version not valid*/
  }
}

/**
 * parse_cmd-: updating relays according to the command
 * args: void
 * ret: void
 **/
void check_cmd(int cmd, String peripherals, String url, String weather, String src) {
  switch(cmd) {
    case 1:
      // OTA
      updateFirmware(url);
      break;
    case 2: {
      DynamicJsonBuffer jsonBuffer(300);
      JsonObject& device = jsonBuffer.parseObject(peripherals);
      if (!device.success()) {
        PRINTR("invalid json");
        show_notification(invalid_json, 1); 
      }
      for (int i = 1; i<= NUM_RELAYS; i++) {
        String relay_id;
        if (i == 4) {
          relay_id = "usb";
        } else {
          relay_id = "r" + String(i);
        }
        bool r = device.containsKey(relay_id);
        if (r) {
          relay[i].name = (const char *)device[relay_id]["name"];
          relay[i].state = device[relay_id]["state"];
          toggle_relay(i);         
        } else {
          relay[i].name = "\0";
        }
      }
      if (src == "serial-bluetooth") {
        // do nothing
      } else if(src == "wifi") {
        generate_interrupt();
      }
      break;
    }
    case 4: {
      /* request for device status */
      publish_on_telemetry();
      break;
    }
    case 5: {
      /* request for device status */
      DynamicJsonBuffer jsonBuffer(300);
      JsonObject& weather_info = jsonBuffer.parseObject(weather);
      if (!weather_info.success()) {
        PRINTR("invalid json");
        show_notification(invalid_json, 1); 
      }
      const char* temp = weather_info["temp"];
      const char* temp_min = weather_info["temp_min"];
      const char* temp_max = weather_info["temp_max"];
      const char* desc = weather_info["description"];
      const char* icon = weather_info["icon"];
      check_temp_weather (temp, temp_min, temp_max, desc, icon, &_weather);     
      break;
    }
    default:
      /* ERROR */
      break;
  }
}

/**
 * check_temp_weather:- checking weather and temp data
 * ret:- void 
 * args:- void
 **/
void check_temp_weather (const char* temp, const char* temp_min, const char* temp_max, const char* desc, const char* icon, struct temp_weather_def *_weather) {
  String tempT = temp;
  int splitDot = tempT.indexOf(".");
  _weather->temp_Str = tempT.substring(0,splitDot);
  String tempMin = temp_min;
  int splitDot_Min = tempMin.indexOf(".");
  _weather->temp_minStr = tempMin.substring(0,splitDot_Min);
  String tempMax = temp_max;
  int splitDot_Max = tempMax.indexOf(".");
  _weather->temp_maxStr = tempMax.substring(0,splitDot_Max);
  _weather->desc = desc;
  PRINTR(_weather->desc);
  _weather->icon = icon;
  PRINTR(_weather->icon);
}

/**
 * generate_interrupt - generating interupt using GPIO pin
 * args: void
 * ret: void 
 */
void generate_interrupt() {
  // request for device status
  digitalWrite(JSON_INTERRUPT, LOW);
  DELAY_100;
  digitalWrite(JSON_INTERRUPT, HIGH);
  DELAY_100;
}

/**
 * toggle_relay:- toggle relays
 * args: void
 * ret: vpid 
 */
void toggle_relay(int i) {
  digitalWrite(relaygpios[i-1], relay[i].state);
}

/**
 * send_to_server_periodically - creating the task for publish json
 * args: void *pvparameters
 * return: void
 */
void send_to_server_periodically(void *pvParameters) {
  PRINTS("SEND_TO_SERVER running on core");
  PRINTR(xPortGetCoreID());
  for(;;){
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    periodic_response_send();
  }
  DELAY_200;
}

/**
 * periodic_response_send - publish the json periodically
 * args: void
 * return: void
 */
unsigned long lastMillis = 0;
int weather_info;
void periodic_response_send(void) {
  //PRINTR("In periodic_response_send");
  unsigned long currentmillis = millis();
  if ((currentmillis - lastMillis > max_sending_time) || interrupt_flag) {
    if (interrupt_flag) {
      publish_on_telemetry();
    } else {
      lastMillis = currentmillis;
      publish_on_telemetry();
      weather_info++;
    }
  }
  if (weather_info == 240) {
    String weather_api = device_info();
    publish_state(weather_api);
    weather_info = 0;
  }
}

/**
 * publish_json_on_telemetry - publish json string when recieve interrupt_flag as true
 * args: void
 * return: void
 */
void publish_on_telemetry() {
  String response;
  if (interrupt_flag) {
    response = relays_response(false);
    interrupt_flag = false;
  } else {
    response = relays_response(true);
  }
  publish_telemetry(response);
  response = "\0";
  lastMillis = millis();
}

/**
 *publish_Telemetry-> method for sending data
 * args: String data
 * returns: bool
 */
bool publish_telemetry(String data) {
  bool xyz = mqtt->publishTelemetry(data);
  PRINTR(data);
  return xyz;
}

/**
 * relays_response:- response of every relays separatly
 * args:- void
 * ret:- void
 */
String relays_response(bool is_periodic) {
  DynamicJsonBuffer jsonBuffer(300);
  JsonObject& periodic_json = jsonBuffer.createObject();
  periodic_json["device_id"] = _config.cloud_device_id;
  periodic_json["timestamp"] = String(time(nullptr));
  periodic_json["version"] = String(CODE_VERSION);
  if (!is_periodic) {
    periodic_json["status"] = String(cmd);
    periodic_json["commandId"] = random_string;
    JsonObject& peripherals =  periodic_json.createNestedObject("peripherals");
    for (int i = 1; i <= NUM_RELAYS; i++) {
      String relay_id;
      #ifdef WIFIMINI
        relay_id = "r" + String(i);
      #else
        if (i == 4) {
          relay_id = "usb";
        } else {
          relay_id = "r" + String(i);
        }
      #endif
      if (relay[i].name != "\0") {
        JsonObject& per = peripherals.createNestedObject(relay_id);
        per["name"] = relay[i].name;
        per["state"] = String(relay[i].state);
        relay[i].name = "\0";
      }
    }
  } else {
    if (cmd == 4) {
      periodic_json["status"] = String(cmd);
      periodic_json["commandId"] = random_string;
    } else {
      periodic_json["status"] = "3";
      periodic_json["commandId"] = "";
    }
    JsonObject& peripherals = periodic_json.createNestedObject("peripherals");
    for (int i = 1; i <= NUM_RELAYS; i++) {
      String relay_id;
      #ifdef WIFIMINI
        relay_id = "r" + String(i);
      #else
      if (i == 4) {
        relay_id = "usb";
      } else {
        relay_id = "r" + String(i);
      }
      #endif
      peripherals[relay_id + "/state"] = String(relay[i].state);
    }
  }
  String response;
  periodic_json.printTo(response);
  return response;
}

/**
 * send_json - changing the interrupt_flag in bool
 * args: void
 * return: void
 */
void send_json() {
  interrupt_flag = true;
}